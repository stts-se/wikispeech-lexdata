-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ar
-- ------------------------------------------------------
-- Server version	10.1.44-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Entry`
--

DROP TABLE IF EXISTS `Entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wordParts` text,
  `label` varchar(128) DEFAULT NULL,
  `language` varchar(128) NOT NULL,
  `strn` text NOT NULL,
  `lexiconId` int(11) NOT NULL,
  `partOfSpeech` varchar(128) DEFAULT NULL,
  `morphology` varchar(128) DEFAULT NULL,
  `preferred` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `language` (`language`),
  KEY `strn` (`strn`(191)),
  KEY `lexiconId` (`lexiconId`),
  KEY `entrypref` (`preferred`),
  KEY `strnlangue` (`strn`(191),`language`),
  KEY `estrnpref` (`strn`(191),`preferred`),
  KEY `idid` (`id`,`lexiconId`),
  CONSTRAINT `fk_3` FOREIGN KEY (`lexiconId`) REFERENCES `Lexicon` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Entry`
--

LOCK TABLES `Entry` WRITE;
/*!40000 ALTER TABLE `Entry` DISABLE KEYS */;
INSERT INTO `Entry` VALUES (1,'bob',NULL,'en','bob',1,'','',0),(2,'dylan',NULL,'en','dylan',1,'','',0),(3,'volvo',NULL,'en','volvo',1,'','',0),(4,'بوب',NULL,'ar','بوب',1,'','',0),(5,'ديلن',NULL,'ar','ديلن',1,'','',0),(6,'فولفو',NULL,'en','فولفو',1,'','',0);
/*!40000 ALTER TABLE `Entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EntryComment`
--

DROP TABLE IF EXISTS `EntryComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EntryComment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `source` text,
  `label` text NOT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `fk_5` (`entryId`),
  KEY `cmtlabelndx` (`label`(191)),
  KEY `cmtsrcndx` (`source`(191)),
  CONSTRAINT `fk_5` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EntryComment`
--

LOCK TABLES `EntryComment` WRITE;
/*!40000 ALTER TABLE `EntryComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `EntryComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EntryStatus`
--

DROP TABLE IF EXISTS `EntryStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EntryStatus` (
  `name` varchar(128) NOT NULL,
  `source` varchar(128) NOT NULL,
  `entryId` int(11) NOT NULL,
  `Timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `current` tinyint(1) NOT NULL DEFAULT '1',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryId` (`entryId`,`id`),
  UNIQUE KEY `eseii` (`id`,`entryId`),
  UNIQUE KEY `eseiicurr` (`id`,`entryId`,`current`),
  UNIQUE KEY `idcurr` (`id`,`current`),
  KEY `esn` (`name`),
  KEY `ess` (`source`),
  KEY `esc` (`current`),
  KEY `esceid` (`entryId`),
  KEY `entryidcurrent` (`entryId`,`current`),
  CONSTRAINT `fk_7` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EntryStatus`
--

LOCK TABLES `EntryStatus` WRITE;
/*!40000 ALTER TABLE `EntryStatus` DISABLE KEYS */;
INSERT INTO `EntryStatus` VALUES ('imported','hb',1,'2020-04-24 16:19:04',1,1),('imported','hb',2,'2020-04-24 16:19:04',1,2),('imported','hb',3,'2020-04-24 16:19:04',1,3),('imported','hb',4,'2020-04-24 16:19:04',1,4),('imported','hb',5,'2020-04-24 16:19:04',1,5),('imported','hb',6,'2020-04-24 16:19:04',1,6);
/*!40000 ALTER TABLE `EntryStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EntryTag`
--

DROP TABLE IF EXISTS `EntryTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EntryTag` (
  `entryId` int(11) NOT NULL,
  `tag` text NOT NULL,
  `wordForm` text,
  UNIQUE KEY `tageid` (`entryId`),
  UNIQUE KEY `tagentwf` (`tag`(128),`wordForm`(128)),
  CONSTRAINT `fk_4` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EntryTag`
--

LOCK TABLES `EntryTag` WRITE;
/*!40000 ALTER TABLE `EntryTag` DISABLE KEYS */;
/*!40000 ALTER TABLE `EntryTag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EntryValidation`
--

DROP TABLE IF EXISTS `EntryValidation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EntryValidation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `level` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `message` text NOT NULL,
  `Timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `evallev` (`level`),
  KEY `evalnam` (`name`),
  KEY `entvalEid` (`entryId`),
  KEY `identvalEid` (`id`,`entryId`),
  CONSTRAINT `fk_6` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EntryValidation`
--

LOCK TABLES `EntryValidation` WRITE;
/*!40000 ALTER TABLE `EntryValidation` DISABLE KEYS */;
/*!40000 ALTER TABLE `EntryValidation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lemma`
--

DROP TABLE IF EXISTS `Lemma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lemma` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reading` varchar(128) NOT NULL,
  `paradigm` varchar(128) DEFAULT NULL,
  `strn` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `strnreading` (`strn`(128),`reading`),
  KEY `reading` (`reading`),
  KEY `paradigm` (`paradigm`),
  KEY `strn` (`strn`(191)),
  KEY `lemidstrn` (`id`,`strn`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lemma`
--

LOCK TABLES `Lemma` WRITE;
/*!40000 ALTER TABLE `Lemma` DISABLE KEYS */;
/*!40000 ALTER TABLE `Lemma` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lemma2Entry`
--

DROP TABLE IF EXISTS `Lemma2Entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lemma2Entry` (
  `entryId` int(11) NOT NULL,
  `lemmaId` int(11) NOT NULL,
  UNIQUE KEY `lemmaId` (`lemmaId`,`entryId`),
  UNIQUE KEY `l2euind` (`lemmaId`,`entryId`),
  UNIQUE KEY `idx46cf073d` (`entryId`),
  KEY `l2eind2` (`lemmaId`),
  CONSTRAINT `fk_1` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_2` FOREIGN KEY (`lemmaId`) REFERENCES `Lemma` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lemma2Entry`
--

LOCK TABLES `Lemma2Entry` WRITE;
/*!40000 ALTER TABLE `Lemma2Entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `Lemma2Entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lexicon`
--

DROP TABLE IF EXISTS `Lexicon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lexicon` (
  `name` varchar(128) NOT NULL,
  `symbolSetName` varchar(128) NOT NULL,
  `locale` varchar(128) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `namesymset` (`name`,`symbolSetName`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lexicon`
--

LOCK TABLES `Lexicon` WRITE;
/*!40000 ALTER TABLE `Lexicon` DISABLE KEYS */;
INSERT INTO `Lexicon` VALUES ('ar-test','ar_ws-sampa','ar_AR',1);
/*!40000 ALTER TABLE `Lexicon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SchemaVersion`
--

DROP TABLE IF EXISTS `SchemaVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SchemaVersion` (
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SchemaVersion`
--

LOCK TABLES `SchemaVersion` WRITE;
/*!40000 ALTER TABLE `SchemaVersion` DISABLE KEYS */;
INSERT INTO `SchemaVersion` VALUES ('3.1');
/*!40000 ALTER TABLE `SchemaVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Transcription`
--

DROP TABLE IF EXISTS `Transcription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Transcription` (
  `entryId` int(11) NOT NULL,
  `preference` int(11) DEFAULT NULL,
  `label` varchar(128) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(128) NOT NULL,
  `strn` text NOT NULL,
  `sources` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `traeid` (`entryId`),
  KEY `idtraeid` (`id`,`entryId`),
  CONSTRAINT `fk_8` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Transcription`
--

LOCK TABLES `Transcription` WRITE;
/*!40000 ALTER TABLE `Transcription` DISABLE KEYS */;
INSERT INTO `Transcription` VALUES (1,NULL,NULL,1,'ar','\' b o b','hb'),(2,NULL,NULL,2,'ar','\' d i . l a n','hb'),(3,NULL,NULL,3,'ar','\' v o l . v o:','hb'),(4,NULL,NULL,4,'ar','\' b o b','hb'),(5,NULL,NULL,5,'ar','\' d i . l a n','hb'),(6,NULL,NULL,6,'ar',':\' v o l . v o','hb');
/*!40000 ALTER TABLE `Transcription` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-24 16:19:48
